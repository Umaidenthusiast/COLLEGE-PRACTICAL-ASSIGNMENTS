import java.util.Scanner;
class Person
{
   String name;
   int age;

   void getPersonData()
   {
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter a name:  ");
      name = sc.nextLine();
      System.out.println("Enter your age:   ");
      age = sc.nextInt(); 

       }
    void DisplayPersonData()
      {
        System.out.println("Name is: "+name);
        System.out.println("Age is: "+age);

           }
}

class Employee extends Person
{
    int id;
    

    void getEmployeeData()
      {
         getPersonData();     
         Scanner sc = new Scanner(System.in);
         System.out.println("Enter your ID:  ");
         id = sc.nextInt();
   
          } 
 
    void DisplayEmployeeData()
       { 
          DisplayPersonData();
          System.out.println("Employee ID is:   "+id);
              } 
}

public class Inherit
{
     public static void main (String[] args)
     {
     
      Employee e = new Employee();
      
      e.getEmployeeData();
      e.DisplayEmployeeData();  
       }
}
