"""In an e-commerce system,customer account ids are stored in a list,and you are tasked with writing a program that implements the following:
        1) Linear Search: Check if a particular customer account ID exists in the list
        2) Binary Search: Implement Binary Search to check if the customer account ID exists,improving the search efficiency over the basic linear"""

customer_list = []

# Ask for number of customers
while True:
    n = int(input("Enter the number of customers: "))
    break

# Collect customer IDs
for i in range(n):
    cid = int(input(f"Enter customer ID {i+1}: "))
    customer_list.append(cid)

# Ask for the customer ID to search
searchkey = int(input("Enter the customer ID to search: "))

# Ask the user to choose the search method
print("\nChoose search method:")
print("1. Linear Search")
print("2. Binary Search")
choice = int(input("Enter your choice (1 or 2): "))

# Linear search function
def linear_search(arr, target):
    for i in range(len(arr)):
        if arr[i] == target:
            return i
    return -1

# Binary search function
def binary_search(arr, target):
    low = 0
    high = len(arr) - 1

    while low <= high:
        mid = (low + high) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    return -1

# Perform search based on user choice
if choice == 1:
    result = linear_search(customer_list, searchkey)
    print("\nCustomer List:", customer_list)
elif choice == 2:
    customer_list.sort()  # Must sort before binary search
    result = binary_search(customer_list, searchkey)
    print("\nCustomer List (sorted):", customer_list)
else:
    print("Invalid choice.")
    result = -1

# Output result
if result != -1:
    print(f"Customer ID {searchkey} found at position {result}.")
else:
    print(f"Customer ID {searchkey} NOT found in the list.")
