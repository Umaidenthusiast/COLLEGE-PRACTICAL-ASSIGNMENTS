import java.util.Scanner;
public class Hotel
{
  public static void main (String[] args)
   {
     Scanner sc = new Scanner(System.in);
     int [][]arr = new int [5][4];
     int choice;

     do
     {
     System.out.println("Hotel Booking System....");
     System.out.println("\n 1 View rooms");
     System.out.println("2 Book a room");
     System.out.println("3 Exit");
     System.out.println("Enter your choice");
     choice = sc.nextInt();
     
     if (choice == 1) 
     {
       System.out.println("Here's the room status");
       for (int i=0;i<5;i++)
        {
          for(int j=0;j<4;j++)
           {
            System.out.print("F"+(i + 1) + "R"+(j + 1)+":");
            System.out.print((arr[i][j] == 0?"Available":"Booked")+ "\t");
            }
         System.out.println();
        }
}
     else if (choice == 2)
      {
       System.out.print("Enter floor (1-5): ");
        int floor = sc.nextInt();

       System.out.print("Enter room (1-4)");
        int room = sc.nextInt();
        if (floor >= 1 && floor <= 5 && room >=1 && room <=4)
           {
             if (arr[floor - 1][room - 1]==0)
              {
                 arr[floor - 1][room - 1]=1;
                System.out.println("Room Booked!!");
              } else{
                 System.out.println("Room already booked sorry for the inconviniece");
                  }
              }
              else {
                System.out.println("Invalid room number");
                   }
         }
       else if (choice == 3)
          {
           System.out.println("No problem");
           }

        } while (choice != 3);

       System.out.println("Thank you!!");
       sc.close();
     }
}    
            
            
       
              
      

