import java.util.InputMismatchException;
import java.util.Scanner;
public class Calculator

{
	public static void main(String [] args)
        {
         char op;
         Scanner sc = new Scanner(System.in);
         try{
           
           
         System.out.println("Enter First Number");
         int num1 = sc.nextInt();

         System.out.println("Enter Second Number");
         int num2 = sc.nextInt();

         int result = 0;
         System.out.println("Enter an Operator(+,-,*,/,%)");
         op = sc.next().charAt(0);

         switch (op){
	 case '+':
             result = num1 + num2;
             System.out.println("Addition is: "+result);
             break;
         case '-':
             result = num1 - num2;
             System.out.println("Subtraction is:  "+result);
             break;
         case '*':
             result = num1 * num2;
             System.out.println("Multiplication is:  "+result);
             break;
         case '/':
           try {
             result = num1 / num2;
             System.out.println("Division is:  "+result);
              } catch (ArithmeticException e)
                  {
                    System.out.println("Error! Cannot divide by zero!");
                  } 
             break;            
         case '%':
           try {
              result = num1 % num2;
             System.out.println("Modulus is:  "+result);
             } catch (ArithmeticException e)
                  {
                    System.out.println("Error! Cannot divide by zero!");
                      }
              break;  
            
         default:
             System.out.println("Invalid Operator:  ");  
         }
       }catch (InputMismatchException e){
        System.out.println("Error!! Please enter numbers only"); 
         
     }
       sc.close();
           
        }

}
