
n=int(input("enter the number of element"))
Found =False
for i in range(n)
   if nl=list1[i]
   print"Elment found at (i) index")
   Found=True
     break
if Found=False
print("Element not found")

     





















